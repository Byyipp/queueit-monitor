# queueitmonitor

Input proxies into txt file with ip:port:user:pass format

Proxy Rotation for every Get Request

Will monitor all footsite queueit changes for any product (url is hidden / taken out for privacy reasons)

For education purposes


![image](https://user-images.githubusercontent.com/81348501/133715106-54f02200-12fb-40ab-95dc-640de0aa0626.png)


![image](https://user-images.githubusercontent.com/81348501/133715200-6ff52071-af36-4a5f-a5dc-703b4b70142a.png)
